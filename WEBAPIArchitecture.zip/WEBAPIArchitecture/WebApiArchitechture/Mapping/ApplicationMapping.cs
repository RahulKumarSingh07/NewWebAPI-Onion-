﻿using AutoMapper;
using DomianLayer.EntityModels;
using DomianLayer.EntityViewModels;
using ReposatioryLayer.DataBaseEntity;

namespace WebApiArchitechture.Mapping
{
    public class ApplicationMapping : Profile
    {
        public ApplicationMapping()
        {
            CreateMap<UserViewModel, ApplicationUser>().ReverseMap();
            CreateMap<StudentViewModel, Student>().ReverseMap();
        }
    }
}
