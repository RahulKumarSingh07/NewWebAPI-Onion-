﻿using DomianLayer.EntityViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ServicesLayer.Interfaces;
using System.Net;

namespace WebApiArchitechture.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class StudentController : ControllerBase
    {
        #region<Property>
        private IStudent _student;
        #endregion

        #region<Constructor>
        public StudentController(IStudent student)
        {
            _student = student;
        }
        #endregion

        #region<Post Methods>
        [HttpPost(nameof(AddOrUpdate))]
        public async Task<IActionResult> AddOrUpdate(StudentViewModel studentView)
        {
            ResponseModel responseModel = new ResponseModel();
            if (studentView == null)
            {
                responseModel.Message = "Enter Details";
                responseModel.Code = (int)HttpStatusCode.NoContent;
                return Ok(responseModel);
            }
            else
            {
                var getresponse = await _student.AddStudent(studentView);
                if (getresponse)
                {
                    responseModel.Data = getresponse;
                    responseModel.Message = "Student Added Successfully";
                    responseModel.Code = (int)HttpStatusCode.OK;
                }
                else
                {
                    responseModel.Data = getresponse;
                    responseModel.Message = "Something Went Worng";
                    responseModel.Code = (int)HttpStatusCode.BadRequest;
                }
                return Ok(responseModel);
            }
        }
        #endregion

        #region<Get Methods>
        #endregion

        #region<Delete Method>
        #endregion

        #region<Put Method>
        #endregion

    }
}
