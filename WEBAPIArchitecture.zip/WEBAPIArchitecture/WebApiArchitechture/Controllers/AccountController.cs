﻿using DomianLayer.EntityViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using ReposatioryLayer.DataBaseEntity;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Security.Claims;
using System.Text;

namespace WebApiArchitechture.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AccountController : ControllerBase
    {
        #region <Property>
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IConfiguration _configuration;
        #endregion

        #region <Contructor>
        public AccountController(SignInManager<ApplicationUser> signInManager, 
            UserManager<ApplicationUser> userManager,
            IConfiguration configuration)
        {
            _signInManager = signInManager;
            _userManager = userManager;
            _configuration = configuration;
        }
        #endregion
        #region <GET Methods>

        #endregion

        #region <POST Methods>
        [AllowAnonymous]
        [HttpPost(nameof(LogIn))]
        public async Task<IActionResult> LogIn(LoginViewModel logInModel)
        {
            LoginViewModel objLogInModel;
            ResponseModel responseModel = new ResponseModel();
            try
            {
                if (logInModel != null)
                {
                    var getUserByUserName = await _userManager.FindByNameAsync(logInModel.UserName);
                    if (getUserByUserName != null)
                    {
                        if (await _userManager.CheckPasswordAsync(getUserByUserName, logInModel.Password) == true)
                        {
                            var result = await _signInManager.PasswordSignInAsync(getUserByUserName, logInModel.Password, false, false);
                            if (result.Succeeded)
                            {
                                objLogInModel = new LoginViewModel()
                                {
                                    UserName = logInModel.UserName,
                                    Token = GetToken(getUserByUserName.UserName, getUserByUserName.Email, getUserByUserName.Id),
                                };
                                responseModel.Data = objLogInModel;
                                responseModel.Message = "Login Successfully";
                                responseModel.Code = (int)HttpStatusCode.OK;
                                return Ok(responseModel);
                            }
                            else if (result.IsLockedOut)
                            {
                                
                            }
                            else if (result.RequiresTwoFactor) 
                            { 

                            }
                            else
                            {
                                responseModel.Message = "Incorrect UserName And Password";
                                responseModel.Code = (int)HttpStatusCode.Unauthorized;
                                return Ok(responseModel);
                            }
                        }
                        else
                        {
                            responseModel.Message = "Incorrect UserName And Password";
                            responseModel.Code = (int)HttpStatusCode.Unauthorized;
                            return Ok(responseModel);
                        }
                    }
                    else
                    {
                        responseModel.Message = "Not Found";
                        responseModel.Code = (int)HttpStatusCode.NotFound;
                        return Ok(responseModel);
                    }
                }
                else
                {
                    responseModel.Message = "Enter UserName And PassWord";
                    responseModel.Code = (int)HttpStatusCode.NotFound;
                }
                return Ok(responseModel);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [HttpPost(nameof(LogOut))]
        public async Task<IActionResult> LogOut()
        {
            ResponseModel responseModel = new ResponseModel();
            await _signInManager.SignOutAsync();
            responseModel.Code = (int)HttpStatusCode.OK;
            responseModel.Message = "Logout Successfully";
            return Ok(responseModel);

        }


        private string GetToken(string userName,string email,Guid userID)
        {
            //create claims details based on the user information
            var claims = new[] {
                        new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                        new Claim("UserId", userID.ToString()),
                        new Claim("UserName", userName),
                        new Claim("Email",email)
                    };
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                _configuration["Jwt:Issuer"],
                _configuration["Jwt:Audience"],
                claims,
                expires: DateTime.UtcNow.AddMinutes(60),
                signingCredentials: signIn);

            return new JwtSecurityTokenHandler().WriteToken(token);
            
        }
        #endregion
    }
}
