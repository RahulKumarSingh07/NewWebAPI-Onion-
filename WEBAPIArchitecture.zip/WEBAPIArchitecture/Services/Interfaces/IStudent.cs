﻿using DomianLayer.EntityViewModels;

namespace ServicesLayer.Interfaces
{
    public interface IStudent
    {
        Task<StudentViewModel> GetByIdAsync(int id);
        Task<IReadOnlyList<StudentViewModel>> GetAllAsync();
        Task<bool> UpdateStudentAsync(StudentViewModel student);
        Task<bool> DeleteStudentAsync(StudentViewModel student);
        Task<bool> AddStudent(StudentViewModel student);
        Task<bool> UpdateRangeStudentAsync(IEnumerable<StudentViewModel> students);
        Task<bool> RemoveRangeStudentAsync(IEnumerable<StudentViewModel> students);
        Task<bool> AddRangeStudentAsync(IEnumerable<StudentViewModel> students);

    }
}
