﻿using AutoMapper;
using DomianLayer.EntityModels;
using DomianLayer.EntityViewModels;
using ReposatioryLayer;
using ServicesLayer.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServicesLayer
{
    public class StudentService : IStudent
    {
        #region<Property>
        private readonly IUnitOfWork<Student> _unitOfWork;
        private readonly IMapper _mapper;
        #endregion

        #region<Contructor>
        public StudentService(IUnitOfWork<Student> unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }
        #endregion

        #region<Methods>
        public async Task<bool> AddRangeStudentAsync(IEnumerable<StudentViewModel> students)
        {
            try
            {
                var getReposatiory = _unitOfWork.asynReposatiory;
                var mapStudent = _mapper.Map<IEnumerable<Student>>(students);
                var addMultipleStudent =await getReposatiory.AddRangeAsync(mapStudent);
                if (addMultipleStudent) return true;
                else return false; 
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<bool> AddStudent(StudentViewModel student)
        {
            try
            {
                var getReposatiory = _unitOfWork.asynReposatiory;
                var mapStudent = _mapper.Map<Student>(student);
                var addStudent = await getReposatiory.AddAsync(mapStudent);
                if (addStudent) return true;
                else return false;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public Task<bool> DeleteStudentAsync(StudentViewModel student)
        {
            throw new NotImplementedException();
        }

        public Task<IReadOnlyList<StudentViewModel>> GetAllAsync()
        {
            throw new NotImplementedException();
        }

        public Task<StudentViewModel> GetByIdAsync(int id)
        {
            throw new NotImplementedException();
        }

        public Task<bool> RemoveRangeStudentAsync(IEnumerable<StudentViewModel> students)
        {
            throw new NotImplementedException();
        }

        public Task<bool> UpdateRangeStudentAsync(IEnumerable<StudentViewModel> students)
        {
            throw new NotImplementedException();
        }

        public Task<bool> UpdateStudentAsync(StudentViewModel student)
        {
            throw new NotImplementedException();
        }
        #endregion

    }
}
