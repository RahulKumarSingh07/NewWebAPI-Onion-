﻿using DropDown.Models;

namespace DropDown.ViewModel
{
    public class CascadingVieModel
    {
        List<Country> CountryList { get; set; }
        List<State> StatesList { get; set; }
        List<City> CitiesList { get; set; }
       // Country CountryData { get; set; }
        
    }
}
