﻿using DropDown.Models;

namespace DropDown.Repo.Interfaces
{
    public interface ICSCLIST
    {
        public List<Country> GetAllCountry();
        public List<State> GetStatesByCountryId(int countryId);
        public List<City> GetCityByStateId(int stateId);
    }
}
