﻿using DropDown.Models;
using DropDown.Repo.Interfaces;

namespace DropDown.Repo
{
    public class ISCLISTService : ICSCLIST
    {
        private readonly ApplicationContext _applicationContext;
        public ISCLISTService(ApplicationContext applicationContext)
        {
            _applicationContext= applicationContext;
        }

        public List<Country> GetAllCountry()
        {
            var getCountryList = _applicationContext.Tblcountries.ToList();
            return getCountryList;
        }

        public List<City> GetCityByStateId(int stateId)
        {
            var getCityList  = _applicationContext.Tblcity.Where(x => x.StateId == stateId).ToList();
            return getCityList;
        }

        public List<State> GetStatesByCountryId(int countryId)
        {
            var getStateList = _applicationContext.Tblstate.Where(x => x.CountryId == countryId).ToList();
            return getStateList;
        }
    }
}
