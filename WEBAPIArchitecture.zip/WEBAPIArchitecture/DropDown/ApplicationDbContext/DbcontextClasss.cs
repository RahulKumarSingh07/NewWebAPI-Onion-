﻿using DropDown.Models;
using Microsoft.EntityFrameworkCore;

namespace DropDown.ApplicationDbContext
{
    public class DbcontextClasss
    {
        //public DbcontextClasss(DbContextOptions<DbcontextClasss> options) : base(options)
        //{

        //}
        //public DbSet<Country> Tblcountries { get; set; }
        //public DbSet<State> Tblstate { get; set; }
        //public DbSet<City> Tblcity { get; set; }
    }
}
