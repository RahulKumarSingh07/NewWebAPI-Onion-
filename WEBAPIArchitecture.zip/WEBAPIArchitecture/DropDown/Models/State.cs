﻿namespace DropDown.Models
{
    public class State
    {
        public int Id { get; set; }
        public int CountryId { get; set; }
        public string StateName { get; set; }
    }
}
