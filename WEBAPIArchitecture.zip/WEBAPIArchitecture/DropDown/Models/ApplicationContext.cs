﻿using DropDown.ApplicationDbContext;
using Microsoft.EntityFrameworkCore;

namespace DropDown.Models
{
    public class ApplicationContext : DbContext
    {
        public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options)
        {

        }
        public DbSet<Country> Tblcountries { get; set; }
        public DbSet<State> Tblstate { get; set; }
        public DbSet<City> Tblcity { get; set; }
    }
}
