﻿

namespace ReposatioryLayer
{
    public interface IAsynReposatiory<T>
    {
        public Task<T> GetByIdAsync(int id);
        public Task<T> GetByGuidIdAsync(string id);
        public Task<bool> DeleteAsync (T entity);
        public Task<bool> UpdateAsync(T entity);
        public Task<bool> AddAsync(T entity);
        public Task<IEnumerable<T>> GetAllAsync();
        public Task<bool> AddRangeAsync(IEnumerable<T> entities);
        public Task<bool> RemoveRangeAsync(IEnumerable<T> entities);
        public Task<bool> UpdateRangeAsync(IEnumerable<T> entities);


    }
}
