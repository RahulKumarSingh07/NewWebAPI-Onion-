﻿using DomianLayer.EntityModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace ReposatioryLayer.DataBaseEntity
{
    public  class ApplicationDbContext :IdentityDbContext<ApplicationUser, IdentityRole<Guid>, Guid>,IDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
        public DbSet<Student> tblStudent { get; set; }


    }
}
