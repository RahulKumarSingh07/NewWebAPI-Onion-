﻿using Microsoft.AspNetCore.Identity;


namespace ReposatioryLayer.DataBaseEntity
{
    public class ApplicationUser : IdentityUser<Guid>
    {
        public ApplicationUser() :base(){}
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
    }

    

}
