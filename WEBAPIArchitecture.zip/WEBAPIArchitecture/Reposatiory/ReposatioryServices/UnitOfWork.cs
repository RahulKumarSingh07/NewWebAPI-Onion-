﻿

using DomianLayer.EntityModels;
using Microsoft.EntityFrameworkCore;

namespace ReposatioryLayer.ReposatioryServices
{
    public class UnitOfWork<T> : IUnitOfWork<T> where T : class
    {
        #region <Property>
        private readonly IDbContext _dbContext;
        private Dictionary<Type, Object> _reposatiory;

        #endregion

        #region <Contructer>
        public UnitOfWork(IDbContext dbContext)
        {
            _dbContext = dbContext;
            asynReposatiory = new Reposatiory<T>(dbContext);
            reposatiory = new Reposatiory<T>(dbContext);
        }
        #endregion

        #region <Methods Declarations>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool dispoint)
        {
            if (_dbContext != null)
            {
                _dbContext.Dispose();
            }
        }
        #region <Get Repo>
        //public IAsynReposatiory<TEntity> GetAsynReposatiory<TEntity>() where TEntity : class
        //{
        //    if (_reposatiory == null)
        //    {
        //        this._reposatiory = new Dictionary<Type, object>();
        //    }
        //    var type = typeof(TEntity);
        //    if (!this._reposatiory.ContainsKey(type))
        //    {
        //        this._reposatiory[type] = new Reposatiory<TEntity>(this._dbContext);
        //    }
        //    return (IAsynReposatiory<TEntity>)this._reposatiory[type];

        //}

        //public IReposatiory<TEntity> GetReposatiory<TEntity>() where TEntity : class
        //{
        //    throw new NotImplementedException();
        //}
        #endregion
        //New Ways To Get Reposatiory;
        public IAsynReposatiory<T> asynReposatiory { get; }

        public IReposatiory<T> reposatiory { get; }

        #endregion
    }
}
