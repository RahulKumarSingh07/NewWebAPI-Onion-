﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReposatioryLayer.ReposatioryServices
{
    public class Reposatiory<T> : IReposatiory<T>, IAsynReposatiory<T> where T : class
    {
        #region<Property>
        private readonly DbSet<T> _dbSet;
        private readonly IDbContext _dbContext;
        #endregion

        #region<Constructer>
        public Reposatiory(IDbContext dbContext)
        {
            _dbContext = dbContext;
            _dbSet = dbContext.Set<T>();

        }
        #endregion

        #region <Generic NonAsync Methods>
        public T Add(T entity)
        {
            _dbSet.Add(entity);
            var result = _dbContext.SaveChanges();
            if (result == 0)
            {
                return null;
            }
            return entity;
        }
        public bool Delete(T entity)
        {
            _dbSet.Remove(entity);
            var result = _dbContext.SaveChanges();
            if (result == 0)
            {
                return false;
            }
            return true;
        }
        public IEnumerable<T> GetAll()
        {
            var resultList = _dbSet.ToList();
            return resultList;
        }
        public bool Update(T entity)
        {
            _dbSet.Update(entity);
            var result = _dbContext.SaveChanges();
            if (result == 0)
            {
                return false;
            }
            return true;
        }
        public T GetByStringId(string id)
        {
            var resultEntity = _dbSet.Find(id);
            return resultEntity;
        }
        public T GetById(int id)
        {
            var resultEntity = _dbSet.Find(id);
            return resultEntity;
        }
        #endregion

        #region <Generic Async Methods>
        public async Task<bool> AddAsync(T entity)
        {
            await _dbSet.AddAsync(entity);
            var result = await _dbContext.SaveChangesAsync(default).ConfigureAwait(false);
            if (result > 0 ) { return true; }
            return false;
        }

        public async Task<bool> AddRangeAsync(IEnumerable<T> entities)
        {
            await _dbSet.AddRangeAsync(entities);
            var result = await _dbContext.SaveChangesAsync(default);
            if (result > 0)
            {
                return true;
            }
            return false;
        }

        public async Task<bool> UpdateAsync(T entity)
        {
            _dbSet.Update(entity);
            var result = await _dbContext.SaveChangesAsync(default);
            if (result == 0)
            {
                return false;
            }
            return true;
        }

        public async Task<bool> UpdateRangeAsync(IEnumerable<T> entities)
        {
            _dbSet.UpdateRange(entities);
            var result = await _dbContext.SaveChangesAsync(default);
            if (result == 0)
            {
                return false;
            }
            return true;
        }

        public async Task<bool> RemoveRangeAsync(IEnumerable<T> entities)
        {
            _dbSet.RemoveRange(entities);
            var result = await _dbContext.SaveChangesAsync(default);
            if (result == 0)
            {
                return false;
            }
            return true;
        }

        public async Task<bool> DeleteAsync(T entity)
        {
            _dbSet.Remove(entity);
            var result = await _dbContext.SaveChangesAsync(default);
            if (result == 0)
            {
                return false;
            }
            return true;
        }

        public async Task<IEnumerable<T>> GetAllAsync()
        {
            var resultEntity = await _dbSet.ToListAsync();
            return resultEntity;
        }
        public async Task<T> GetByGuidIdAsync(string id)
        {
            var resultEntity = await _dbSet.FindAsync(id);
            return resultEntity;
        }
        public async Task<T> GetByIdAsync(int id)
        {
            var resultEntity = await _dbSet.FindAsync(id);
            return resultEntity;
        }
        #endregion

    }
}
