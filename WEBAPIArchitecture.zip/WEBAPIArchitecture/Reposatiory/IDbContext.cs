﻿using Microsoft.EntityFrameworkCore;

namespace ReposatioryLayer
{
    public interface IDbContext : IDisposable
    {
        //Used For Commit Transection
        Task<int> SaveChangesAsync(CancellationToken cancellationToken);
        int SaveChanges();
        DbSet<TEntity> Set<TEntity>() where TEntity : class;
    }
}
